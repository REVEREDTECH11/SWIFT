//
//  Pick_a_PalTests.swift
//  Pick-a-PalTests
//
//  Created by Greg Lamar Jr on 10/29/25.
//

import Testing
@testable import Pick_a_Pal

struct Pick_a_PalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
