//
//  Pick_a_PalApp.swift
//  Pick-a-Pal
//
//  Created by Greg Lamar Jr on 10/29/25.
//

import SwiftUI

@main
struct Pick_a_PalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
